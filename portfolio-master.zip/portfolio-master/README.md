# My Portfolio website

[![Netlify Status](https://api.netlify.com/api/v1/badges/dd7c7e3f-1693-4088-96d0-6e6578698df8/deploy-status)](https://app.netlify.com/sites/davisilva/deploys)

Here is a visual representation of my career path so far.

Available on:
<a href="https://davisilva.netlify.app" target="_blank" rel="noopener noreferrer">https://davisilva.netlify.app</a>